// $(document).ready(function(){
//         $('img[src="help.png"]').mouseover(function(){
//            $('#'+getDivId(this)).fadeIn(1);
//     }).mouseout(function(){
//          $('#'+getDivId(this)).fadeOut(1);
//     });
//     function getDivId(icon)
//     {
//         var helpIconId=$(icon).attr('id');
//         return helpIconId.replace('img', 'div');
   
//     }
        
    
// });




// //instead of using mouseover() and mouseout() function we can also use mouseenter() and mouseleave() function respectively, below are the code
// $(document).ready(function(){
//     $('img[src="help.png"]').mouseenter(function(){
//        $('#'+getDivId(this)).fadeIn(1);
// }).mouseleave(function(){
//      $('#'+getDivId(this)).fadeOut(1);
// });
// function getDivId(icon)
// {
//     var helpIconId=$(icon).attr('id');
//     return helpIconId.replace('img', 'div');

// }
    

// });


// we can also use hover() method which takes two functions as an argument, below are the code

$(document).ready(function(){
    $('img[src="help.png"]').hover(function(){
       $('#'+getDivId(this)).fadeIn(1);
       $(this).css('cursor','pointer');
},function()
{
     $('#'+getDivId(this)).fadeOut(1);
});
function getDivId(icon)
{
    var helpIconId=$(icon).attr('id');
    return helpIconId.replace('img', 'div');

}
    

});



