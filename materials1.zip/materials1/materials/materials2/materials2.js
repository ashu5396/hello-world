$(document).ready(function(){
   
    $('#close-button').click(function(){
        callToggleFunction();
       
    })
  

    var callToggleFunction=function(){
        $('#modal').toggle();
        $('#modal-overlay').toggle();
    }

    $('.button-div button').click(function(){
        $('.button-div button').removeClass('clicked');
        $(this).addClass('clicked')

    })
    $('#no-button').click(function(){
        $('#modal').addClass('new-modal-structure');
        $('.add-plot-address-title').addClass('new-add-plot-address-title');
        $('.modal-contents .Is-your-plot-address').hide()
        $('.modal-contents .complete-address-div').hide()
        $('.modal-contents .button-div').hide()
        $('.location-search-div').addClass('show');
        $('.map-image-div').addClass('show')
    })
})