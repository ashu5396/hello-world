$(document).ready(function(){
   
  $('#close-button').click(function(){
      callToggleFunction();
     
  })
  $('#update-address-div button').click(function(){
    $('#modal').removeClass('new-modal-structure');
    $('.add-plot-address-title').removeClass('new-add-plot-address-title');
    $('.modal-contents .Is-your-plot-address').show()
    $('.modal-contents .complete-address-div').show()
    $('.modal-contents .button-div').show()
    $('.location-search-div').removeClass('show');
    $('.map-image-div').removeClass('show')
    $('.tooltip-div').hide();
    $('#confirm-button-div').hide();
    $('#address-form').hide();
    callToggleFunction();
  })


  var callToggleFunction=function(){
      $('#modal').toggle();
      $('#modal-overlay').toggle();
  }

  $('.button-div button').click(function(){
      $('.button-div button').removeClass('clicked');
      $(this).addClass('clicked')

  })
  $('#no-button').click(function(){
      $('#modal').addClass('new-modal-structure');
      $('.add-plot-address-title').addClass('new-add-plot-address-title');
      $('.modal-contents .Is-your-plot-address').hide()
      $('.modal-contents .complete-address-div').hide()
      $('.modal-contents .button-div').hide()
      $('.location-search-div').addClass('show');
      $('.map-image-div').addClass('show')
      $('.tooltip-div').css('display','block');
      $('#confirm-button-div').show();
  })
  $('#confirm-button-div #confirm-button').click(function(){
      $('#address-form').show();
      $('#confirm-button-div').hide();
  })
})