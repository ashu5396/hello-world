/*When several calls to animate() method 
are chained together. By default these calls 
are placed into a queue to be executed one after 
the other in series rather than executing all of 
them simultaneously in parallel. The name of this 
queue is fx.
 */



// $(document).ready(function(){
//     $('#myButton').click(function(){
//         $('#myDiv1').animate({'width':'500'},1500)
//         .animate({'padding':'20'},1500)   
//         .queue(function(){                              // here we are finding 
//             console.log($(this).queue('fx').length);    //the length of the queue i.e. fx queue. currently queue is of 4 size. one function in the queue method and three .animate() method
//             $(this).dequeue() // when we queue a method to execute, we have to dequeue it implicitly
//         })    
        
//         .animate({'font-size':'50'},1500)
//         .animate({'border-width':'10'},1500)
//         .animate({'opacity':1},1500)
          

//         $('#myDiv2').animate({'width':'500'},1500)
//         .animate({'padding':'20'},1500)        
//         .animate({'font-size':'50'},1500)
//         .animate({'border-width':'10'},1500)
//         .animate({'opacity':1},1500);
//     })
        
        
// });


// To globally disable all animation: "$.fx.off=true" or "jquery.fx.off=true"
// let us use one checkbox, when we click on that check box and after that when we click on start animation button, animation should not work. css will be applied, i.e. width, opacity, padding, color, etc should change but animation will not work
// below are the code

// $(document).ready(function(){

//      $('#myButton').click(function(){
//         $.fx.off=$('#myCheckBox').is(':checked'); //is() method returns true or false boolean value depending on whether checkbox is checked or not
//         $('#myDiv1').animate({'width':'500'},1500)
//         .animate({'padding':'20'},1500)          
//         .animate({'font-size':'50'},1500)
//         .animate({'border-width':'10'},1500)
//         .animate({'opacity':1},1500)
          

//         $('#myDiv2').animate({'width':'500'},1500)
//         .animate({'padding':'20'},1500)        
//         .animate({'font-size':'50'},1500)
//         .animate({'border-width':'10'},1500)
//         .animate({'opacity':1},1500);
//     })
        
        
// });

// If we want the calls to animate() method to be 
//executed simultaneously in parellel and not after another, then set 
//queue option to false

/*There are 2 variations of animate method. We discussed Variation 1 in above examples. 
In the code snippet below we are using Variation 2. 

Variation 1
.animate( properties [, duration ] [, easing ] [, complete ] )

Variation 2
.animate( properties, options ) */

//below are the code

// below we are using variants 2 of animate method i.e. animate(properties,options)


// $(document).ready(function(){

//     $('#myButton').click(function(){
//        $.fx.off=$('#myCheckBox').is(':checked'); //is() method returns true or false boolean value depending on whether checkbox is checked or not
//        $('#myDiv1').animate({'width':'500'},{duration:1500, queue:false})  //If we want the calls to animate() method to be executed simultaneously in parellel and not after another, then set queue option to false
//        .animate({'padding':'20'},{duration:1500, queue:false})          
//        .animate({'font-size':'50'},{duration:1500, queue:false})
//        .animate({'border-width':'10'},{duration:1500, queue:false})
//        .animate({'opacity':1},{duration:1500, queue:false})
         

//        $('#myDiv2').animate({'width':'500'},{duration:1500, queue:false})
//        .animate({'padding':'20'},{duration:1500, queue:false})        
//        .animate({'font-size':'50'},{duration:1500, queue:false})
//        .animate({'border-width':'10'},{duration:1500, queue:false})
//        .animate({'opacity':1},{duration:1500, queue:false});
//    })
       
       
// });


//instead of using multiple call to the animate method, we can use all css properties in json object
//below are the code

$(document).ready(function(){

    $('#myButton').click(function(){
       $.fx.off=$('#myCheckBox').is(':checked'); //is() method returns true or false boolean value depending on whether checkbox is checked or not
       $('#myDiv1').animate(
           {
           'width':'500',
           'padding':'20',
           'font-size':'50',
           'border-width':'10',
           'opacity':1
           },1500)  
       

       $('#myDiv2').animate(
           {
           'width':'500',
           'padding':'20',
           'font-size':'50',
           'border-width':'10',
           'opacity':1
           },1500)  
       
   })
       
       
});


