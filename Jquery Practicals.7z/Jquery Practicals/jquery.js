

//Demo of Jquery

$(document).ready(function(){
    $('#division').click(function(){
        $("#division").css('background-color','green')
    });

});
