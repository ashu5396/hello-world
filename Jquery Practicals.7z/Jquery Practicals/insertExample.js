
//insert custom element before and after 

//$(document).ready(function(){
    //$('div').before('<h3>is a software Engineer</h3>');
    // $('<h3>is a software Engineer</h3>').insertBefore('div');    
    // $('div').after('<h3>is a software Engineer</h3>');
    // $('<h3>is a software Engineer</h3>').insertAfter('div');    
    
//});


//insert existing element using before and afer method
//$(document).ready(function(){
   // $('div').before($('#spanElement'));
   // $($('#spanElement')).insertBefore('div');
   //$('div').after($('#spanElement'));
   // $($('#spanElement')).insertAfter('div');

//});