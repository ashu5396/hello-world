// Syntax of jquery animate function
// .animate( properties [, duration ] [, easing ] [, complete ] )

// Animate function has 4 parameters. Only the first parameter (properties) is the required parameter. Rest 3 are optional.
// properties - An object of CSS properties and values
// duration - The duration for animation in milliseconds. Default is 400.
// easing - Easing function to use for the transition. Default is swing. You could also use linear.
// complete - A function to call once the animation is complete

/*What is jQuery easing?

Easing is a technique where the speed and/or direction 
of animation are changed while the animation is in progress.
 Easing can make the animation start off slow and gradually 
 speed up, start up fast and gradually slow down, and a whole 
 host of other effects. The difference between linear and swing 
 easing is very subtle.
*/
// $(document).ready(function(){
//     $('#animate-image').on(
//         {'mouseover':function()
//                     {
//                         $(this).animate({'height':'300px','width':'300px'},1000,'linear',animationComplete)
//                     },
        
//         'mouseout':function()
//                     {
//                         $(this).animate({'height':'100px','width':'100px'},1000)
//                     }
//         }
//         )
//         function animationComplete(){
//             alert('Animation Completed Enjoy !!')
//         }
        
// });

/*In the following example, 
several calls to animate() method 
are chained together. By default
these calls are placed into a queue
to be executed one after the other
in series rather than executing 
all of them simultaneously in parallel. */



$(document).ready(function(){
    $('#animate-image').click(function(){
        $(this).animate({'left':'200'})
        .animate({'top':'200'})        
        .animate({'left':'10'})
        .animate({'top':'10'});
    })
        
        
});


/*Please note: By default, all HTML elements have a static position, and cannot be moved. 
To modify the position , set the CSS position property of the element to fixed, absolute or
 relative. */