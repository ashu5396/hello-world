// $(document).ready(function(){
//     $('#myButton').click(function(){
        
//             var selectedValue=$('#ddlPercentage').val();
//             // var result=''
//             // result=selectedValue.val();
//            // var newWidth=$('#innerDiv').attr('width','selectedValue');
//             $('#innerDiv').animate({'width':(500*selectedValue)/100},3000);
//         })

// })



// if we don't want to have button, if we select a value from dropdown, at the same time only progress bar will work
// below are the code
$(document).ready(function(){
   
        $('#ddlPercentage').change(function(){
            var selectedOption=$('#ddlPercentage option:selected')
            var result=''
              selectedOption.each(function(){
                result=$(this).val();
                $('#innerDiv').animate({
                    'width':(500*result)/100},1500);
                $({counter:result}).animate({counter:result}, {duration:1500,step:function(){$('#innerDiv').text(Math.ceil(this.counter)+"%")}})
                
            });
           
           
                 })
           

})



// $(document).ready(function(){
   
//     $('#ddlPercentage').change(function(){
//         var selectedOption=$('#ddlPercentage option:selected')
//         var result=''
//           selectedOption.each(function(){
//             result=$(this).val();
//             $('#innerDiv').animate({'width':(500*result)/100},1500)
//             $('#innerDiv').text($(this).text()+"%")
//         });
       
       
//              })
       

// })

