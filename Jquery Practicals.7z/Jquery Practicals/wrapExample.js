// $(document).ready(function(){
   
//     $('div').wrap('<div class="container"></div');//this wrap() methods add one parent div to all html dom element. Bellow are the example demonstrated for code written in html page(wrapExample.html)
// });


// //wrap() method wraps each and every dom element with one parent element
// //in our html we have written three div elements, wrap() wiil add one parent div element to each div element that are written in html code

// //<div class="container">
// //  <div>
// //        DIV1
// //   </div>
// //</div>
// //<div class="container">
// //  <div>
// //        DIV2
// //   </div>
// //</div>
// //<div class="container">
// //  <div>
// //        DIV3
// //   </div>
// //</div>



// //unwrap() method removes the parent div from every child div element given in html code
// $(document).ready(function(){

//      $('div').unwrap();
//  });




// //wrapAll() method add one parent div to all div element. it will add only one div element which covers/contains all div element

// $(document).ready(function(){
   
//    $('div').wrapAll('<div class="container"></div');   
// });

// //<div class="container">
// //      <div>
// //          DIV1
// //       </div>
// //      <div>
// //          DIV2
// //      </div>
// //      <div>
// //          DIV3
// //        </div>
// //</div>


//wrapInner() method wrap the html structure around the content of each div element
// example given below

// $(document).ready(function(){
   
//    $('div').wrapInner('<div class="container"></div');   
// });


// //
// //      <div>
// //        <div class="container">
// //            DIV1
// //       </div>
// //       </div>
// //        <div>
// //            <div class="container">
// //               DIV2
// //             </div>
// //        </div>
// //        <div>
// //            <div class="container">
// //              DIV3
// //           </div>
// //        </div>



